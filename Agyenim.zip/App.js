import React from 'react';
import AppNavigator from './assets/Navigation/AppNavigator';
// import Gender from './assets/Onboarding/Gender';
// import Birthday from './assets/Onboarding/Birthday';
// import Location from './assets/Onboarding/Location';
// import Onboard from './assets/Onboarding/Onboard'
// import Login from './assets/Onboarding/Login'
// import Flatlist from './assets/components/Flatlist';
// import Settings from './assets/screens/Settings/Settings';
    // import Drawer from './assets/components/NavigationDrawer/Drawer'; 
    // import Home from './assets/components/NavigationDrawer/Home';


export default class App extends React.Component {    
  render() {
    return(
          <AppNavigator/>  
        // <Location/>
        // <Onboarding/>
        // <Login/>
        // <Gender/>
        // <Birthday/>
        // <Onboard/>
          // <Flatlist/>
          /* <Drawer/> */
          // <Home/>
         
         ); 
  }
}


 