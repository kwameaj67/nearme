import React from 'react';
import {createStackNavigator, createAppContainer} from 'react-navigation';
import Onboard from '../Onboarding/Onboard';
import Gender from '../Onboarding/Gender';
import Location from '../Onboarding/Location';
import Birthday from  '../Onboarding/Birthday';
import Login from '../Onboarding/Login';
import Settings from '../screens/Settings/Settings';
import Info from '../screens/Settings/Info';
import Notifications from '../screens/Settings/Notifications';
import Posts from '../screens/Settings/Posts';
import Replies from '../screens/Settings/Replies';
import Votes from '../screens/Settings/Votes';
import More from '../screens/Settings/More/More';
import About from '../screens/Settings/More/About';
import Help from '../screens/Settings/More/Help';
import Invite from '../screens/Settings/Invite';

const AppStackNavigator = createStackNavigator(
    {
    Login:Login,
    Onboard:Onboard,
    Gender:Gender,
    Age:Birthday,
    Location:Location,
    Settings:Settings,
    Info:Info,
    Notifications:Notifications,
    Posts:Posts,
    Replies:Replies,
    Votes:Votes,
    About:About,
    Help:Help,
    More:More,
    Invite:Invite,
  },
  {
      initialRouteName:"Login",
      defaultNavigationOptions:{
          headerStyle:{
              elevation:0
          }
      }
  }
  
  );
  const AppContainer = createAppContainer(AppStackNavigator);
  
  export default class AppNavigator extends React.Component{
      render()
      {
          return(
                <AppContainer/>
          );
      }
  }

