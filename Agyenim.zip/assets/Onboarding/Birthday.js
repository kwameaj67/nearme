import React from 'react';
import { StyleSheet,View,Text,TouchableHighlight,TextInput,Alert,KeyboardAvoidingView} from 'react-native';
// import Slider from '@react-native-community/slider';
import {Ionicons} from '@expo/vector-icons';





class Birthday extends React.Component{
  constructor(props)
  {
    super(props);
    this.state = {
      dob:'',
      disabled:true,
      modalVisible:false
    }
  } 
  static navigationOptions =({navigation}) => {
    // header:null,
    return{
    // title:'Birthday',
    headerLeft:( 
      <TouchableHighlight
      underlayColor="black"
      activeOpacity={0.45}
       style={{ padding:10}}>
      <Ionicons name="ios-arrow-round-back" size={40} color="rgba(47, 209, 200, 0.77)"
      onPress={()=> navigation.pop()}
      style={{marginLeft:15}}
      />    
      </TouchableHighlight>
 )        
    }
};

 _onchangeText=(target)=>{
    let age = target.nativeEvent.text;
    
      console.log(this.state)
   if(age === " "){
      this.setState({disabled: true});
   }else {
     this.setState({disabled: false})
   }

   this.setState({dob: age})
 }

    _showmodal = () => {
      console.log(this.state)
      if(Number(this.state.dob) <= 17 )
      {
        this.setState({disabled:true})
        Alert.alert("You must be +18 to continue with us.")  
      }
      if (Number(this.state.dob) == " ") {
        this.setState({
          disabled: true
        });
      }
      if (Number(this.state.dob.maxLength) === 2) {
        this.setState({
          disabled: false
        });
      }
      else if(Number(this.state.dob) >= 18)
      {
        this.setState({disabled:false});
           Alert.alert("You are eligible to use this app");
           this.props.navigation.navigate("Location");
           
      }
    }

    _register = () => {
          
    }


    render(){

            return(
              <KeyboardAvoidingView style={styles.container}
                   behavior="padding" enabled={true} keyboardVerticalOffset={1}
                   >   
                  <View style={styles.textView}>
                       <Text style={styles.textStyle}>Tell us your age</Text>
                  </View>            
                        <TextInput
                          style={styles.input}
                          editable = {true}                 
                          placeholder="Enter your age"                      
                          ref = "dob" 
                          onChange={(target) => this._onchangeText(target)}
                          value={this.state.number}
                          keyboardType= "numeric"
                          maxLength={2}
                          autoFocus={true}
                        />            
                        <View>
                        <TouchableHighlight
                        //  underlayColor="transparent"
                      onPress={()=> this._showmodal()}
                      style={styles.cbtn}>
                      <Text style={{ color:"white", fontWeight:'bold', fontSize:16, letterSpacing:0.6}}>Continue</Text>
                       </TouchableHighlight>  
                        </View>
              </KeyboardAvoidingView>
                   
              
            );
    }
}
export default Birthday;
const styles = StyleSheet.create({
    container:{
            flex:1,
            justifyContent:'center',
            backgroundColor:'white'
    },
    textStyle:{
      color:'#4F4F4F',
      top: -140,
      // left:-50,
  fontSize: 35,
  lineHeight:65,
  fontWeight:'700',
  textAlign:'center',
  letterSpacing:0.6,
  },
  
    input:{
      top:-120,
      textAlign:'center',
      borderColor:'#4F4F4F',
       borderWidth: 0.8,
       borderRadius:23,
       marginLeft:50,
       marginRight:50,
       padding:8
    },
    cbtn:{
      backgroundColor:'rgba(47, 209, 200, 0.77)', alignItems:'center',   padding:15,   top:-50,   marginLeft:30,   marginRight:30,   borderRadius:23,   justifyContent:'center',
    },

});