import React from 'react';
import {StyleSheet,View,Text,TouchableHighlight} from 'react-native';
import {Ionicons} from '@expo/vector-icons';
import ShowModal from '../components/ShowModal';


class Gender extends React.Component{
    // constructor(props)
    // {
    //     super(props);
    //     this._onPressAdd = this._onPressAdd.bind();
    // }

    
    state = {
        toggle:false,
        isDisabled:true,
        malegender:"male",
        femalegender:"female",
        modalVisible:true

    }
    _onPressOn() { 
        const newstate = !this.state.toggle;
        this.setState({toggle:newstate});
        let fm = this.setState({femalegender:"female"});
        // Alert.alert(fm);
    }
    _onPressOff() { 
        const newstate = !this.state.toggle;
        this.setState({toggle:newstate});
        let ml = this.setState({malegender:"male"});
        // Alert.alert(ml);
    }

    _handledisable(){
        if(!this._onPress)
        {
            this.setState({isDisabled:true});
        }else{
            this.setState({isDisabled:false});
        }
    }
    setModalVisible(visible){
        this.setState({modalVisible:visible});
    }
    renderModal()
    {
        return(
            <ShowModal          
            visible={this.state.modalVisible}
            />

           
        );
    }


    // _onPressAdd(){
    //     this.refs.addModal.showAddModal();
    // }
    static navigationOptions =({navigation}) => {
            // header:null,
            // title:'Select Gender',
            return{
            headerLeft:( 
     <TouchableHighlight
            underlayColor="#F3EFEF"
            activeOpacity={0.45}
            onPress = {() => navigation.navigate("Onboard")}
            style={{ padding:10}}>
            <Ionicons name="ios-arrow-round-back" size={40} color="rgba(47, 209, 200, 0.77)"
        
        style={{marginLeft:15}} />
      </TouchableHighlight>
            )
   }
            
};
    render(){
       
        const {toggle} = this.state;   
        // const textValue = toggle?"OFF":"ON";
        const buttoncolor1 = toggle?"white":"white";
        const textcolor1 = toggle?"#8D8D8D":"rgba(47, 209, 200, 0.77)";
        const borderColor1 = toggle?"#8D8D8D":"rgba(47, 209, 200, 0.77)";
        //male values
        const buttoncolor2 = toggle?"white":"white";
        const textcolor2 = toggle?"rgba(47, 209, 200, 0.77)":"#8D8D8D";
        const borderColor2 = toggle?"rgba(47, 209, 200, 0.77)":"#8D8D8D";
        
       
            return(
                
                <View style ={styles.container}>
                      <View style={styles.textView}>
                          <Text style={styles.textStyle}>Who are you?</Text>
                      </View>
                  <TouchableHighlight
                             onPress={ ()=> this._onPressOn()}
                            underlayColor="transparent"
                            style={{backgroundColor:buttoncolor1, alignItems:'center', padding:15, top:-120, marginLeft:30,  marginRight:30,  borderRadius:23,  justifyContent:'center',borderWidth:1.8, borderColor:borderColor1}} 
                            >
                      <Text style={{color:textcolor1, fontWeight:'bold', fontSize:16,letterSpacing:0.6}}>Female</Text>
                   </TouchableHighlight>

                   <TouchableHighlight
                    // onPressIn={()=> this.}
                     onPress={()=>this._onPressOff()}
                     underlayColor="transparent"
                    style={{
                    backgroundColor:buttoncolor2,
                    alignItems:'center', 
                    padding:15,
                     top:-100, 
                    marginLeft:30, marginRight:30, borderRadius:23,borderWidth:1.8, justifyContent:'center', borderColor:borderColor2,}}>
                      <Text style={{ color:textcolor2, fontWeight:'bold', fontSize:16,letterSpacing:0.6}}>Male</Text>
                   </TouchableHighlight>
                   
                   <TouchableHighlight
                     underlayColor="transparent"
                     onPress={()=>this.props.navigation.navigate("Age") && this.renderModal()}
                    style={styles.cbutton}>
                      <Text style={styles.ctext}>Continue</Text>
                   </TouchableHighlight>
                  
                </View>
            );
        // return(
        //          <Text> hi kwame </Text>
        // );
       
    }
}
export default Gender;
const styles = StyleSheet.create({
    container:{
        flex:1,
        justifyContent:'center',
        backgroundColor:'white'
    },
    image:{
        width:10,
        height:200,
        position:'absolute',
        // flex:1,
    },
    textStyle:{
        color:'#4F4F4F',  
        top: -200,
    fontSize: 35,
    fontWeight:'700',
    lineHeight:65,
    textAlign:'center',
    letterSpacing:0.6,
    },
    
    cbutton:{
        backgroundColor:'rgba(47, 209, 200, 0.77)', alignItems:'center',   padding:15,   top:50,   marginLeft:30,   marginRight:30,   borderRadius:23,   justifyContent:'center',
    },
    ctext:{
        color:"white", fontWeight:'bold', fontSize:16 , letterSpacing:0.6,
    },
});