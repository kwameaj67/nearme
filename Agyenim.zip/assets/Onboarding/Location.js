import React from 'react';
import { StyleSheet,View,Text,TouchableHighlight,TouchableNativeFeedback,Image} from 'react-native';
import {Ionicons} from '@expo/vector-icons';
import ShowModal from '../components/ShowModal';


class people extends React.Component{
  static navigationOptions =({navigation}) =>  {
    return{
    // title:'Location',
     headerLeft:( 
       <TouchableNativeFeedback useForeground={false} style={{ padding:10,}}>
      <Ionicons name="ios-arrow-round-back" size={40} color="rgba(47, 209, 200, 0.77)"
      onPress={()=> navigation.navigate("Age")}
      style={{marginLeft:15}}
      />
      </TouchableNativeFeedback>
      )
     }
};
    render(){
            return(
                <View style={styles.container}>
                 <Image
                    source={require('../img/the-location-of-the-1724293.png')}
                    style={{ width: 160,height: 160,left: 10,top: -50, marginLeft:50, marginRight:50,}}
                 />
                <Text style={styles.textStyle}>Enable your location</Text>
                <Text style={styles.sloganStyle}>You’ll need to enable your location in order to use Elli</Text>
                
              <TouchableHighlight 
                underlayColor="#625E5E"
                    onPress={()=> this.props.navigation.navigate("Settings")}
                     style={styles.button}>
                      <Text style={styles.text}>Allow location</Text>
                   </TouchableHighlight>
                </View>
            );
    }
}
export default people;
const styles = StyleSheet.create({
    container:{
            alignItems:'center',
            flex:1,
            justifyContent:'center',
            backgroundColor:'white'
    },
    textStyle:{
    color:'#4F4F4F',
    fontSize:22,
    alignItems:'center',
    textAlign:'center',
    fontWeight:'bold',
    height: '-20%',
    marginTop: 20,
    letterSpacing:0.2,
    },
    sloganStyle:{
      color:'#888686',
      fontSize:15,
      alignItems:'center',
      textAlign:'center',
      marginBottom:20,
      marginTop: 50,
      letterSpacing:0.2,
      height: '-10%',
      marginLeft:50,
      marginRight:50,
    },
    button:{
      backgroundColor:'rgba(47, 209, 200, 0.77)', 
      alignItems:'center', 
      width:320,
        padding:15,  
         top:70, 
        marginLeft:30,  
         marginRight:30,   
         borderRadius:23,  
          justifyContent:'center',
     
    },
    text:{
      color:'white',
        fontWeight:'bold',
        fontSize:16,
        alignItems:'center',
        letterSpacing:0.6
    },
});