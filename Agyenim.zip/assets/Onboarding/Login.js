import React from 'react';
import {StyleSheet,View,ImageBackground,Text,TouchableHighlight} from 'react-native';


class Login extends React.Component{
  static navigationOptions = {
    // header:null,   
    header:null,  
};
    render(){
        return(
          <View style={styles.container}>
                 {/* <View style={styles.layer}/>    */}
                <ImageBackground 
                 resizeMode='cover'
                 blurRadius={0.25}
                 style={styles.backgroundImage}
                 source={require('../img/party.jpg')}>
               
                 <View style={styles.buttonStyle}>          
                   <TouchableHighlight 
                   underlayColor="transparent"
                       onPress={()=> this.props.navigation.navigate("Onboard")}
                    style={styles.button}>
                      <Text style={styles.buttontext}>LOGIN</Text>
                      </TouchableHighlight>
                   </View>
                <View style={styles.textStyle}>
                        <Text style={styles.text}>By tapping Login, you agree with our Terms of Service and our Privacy Policy</Text>
                        <Text style={styles.slogan}>{'\u00A9'}2019 Hyperconnect. All rights reserved.</Text>
                </View>      
                
                 </ImageBackground> 
                </View>
        );
    }
} 

export default Login;

const styles = StyleSheet.create({
    container:{
            flex:1,
            justifyContent:'center',
            alignItems:'center',
    },
    backgroundImage:{
        flex:1,
        width:'100%',
        height:'100%',
        opacity:0.9
        
    },
    layer:{
      flex:1,
      backgroundColor:"#D63535",
      opacity:1,
      width:'100%',
        height:'100%',
    },
    textStyle:{
        marginLeft:40,
        marginRight:40,
        alignItems:'center',
    },
    text:{
        color:'white',
        fontSize:13,
        alignSelf:'center',
        textAlign:'center',
        lineHeight:20,
        marginTop:35, 
        letterSpacing:0.2,
        fontWeight:'400'
    },
    slogan:{
      color:'white',
        fontSize:13,
        alignSelf:'center',
        textAlign:'center',
        lineHeight:20,
        marginTop:50, 
        letterSpacing:0.2,
        fontWeight:'400'
    },
    
    button:{
        backgroundColor:'transparent',
          alignItems:'center',
          padding:15,
          marginLeft:40,
         marginRight:40,
          top:20,
          borderRadius:23,
          height:50,    
          justifyContent:'center',
          borderWidth: 2,
          borderColor:'white',
          
      },
      buttontext:{
        color:'white',
        fontWeight:'700',
        fontSize:20,
        justifyContent:'center',
        letterSpacing:0.8
    },
    buttonStyle:{
        marginTop:460,
    }
});
