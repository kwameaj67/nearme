import React from 'react';
import { StyleSheet,View,Text,Image,TouchableHighlight,TouchableNativeFeedback} from 'react-native';
import AppIntroSlider from 'react-native-app-intro-slider';

const slides = [
  {
    key: 'somethun',
    title:'Share your thoughts and connect with people around the world',
    text:'No email or phonenumber required.',
    image:require('../img/connections-2099068_1280.png'),
    text2:'Skip',
    
    
  },
  {
    key: 'somethun-dos',
    title: 'Meet new people and share your experiences.',
    text:'Chat with people around you instantly.',
    image: require('../img/friends-4187953_1280.png'),
    
    
  },
  {
    key: 'somethun1',
    title: 'Check out what people have to say.',
    text: 'Connect with a hyper local commnuinity around you.',
    image:require('../img/social-media-3846597.png'),
   
  }
];

export default class App extends React.Component {  

  static navigationOptions = {
    header:null,

};
  state = {
    showOnboard: false
  }
  
  item_render = (item) => {
    return(
      <View style={styles.slide}>
      
      <TouchableNativeFeedback useForeground={true} background={TouchableNativeFeedback.SelectableBackground()}>
      <Text
       onPress={()=> this.props.navigation.navigate("Gender")} style={styles.styleSkip}>
       {item.text2}
       </Text>
       </TouchableNativeFeedback>
      <Image style={styles.picture} source ={item.image}/> 
    
      <Text style={styles.titleStyle}>{item.title}</Text>
    
     
      <Text style={styles.subtitle}>{item.text}</Text>
      
      </View>
    );
  }
  
  onPress = () =>{
    
  }
  buttonNext = () => {
    return(     
        <TouchableHighlight style={{
         backgroundColor:'rgba(47, 209, 200, 0.77)',
         alignItems:'center',  
          padding:15, 
          width:320, 
          top:-10,  
          marginLeft:30,   
          marginRight:30,   
          borderRadius:23,   
          justifyContent:'center', }}>

          <Text style={{
            color:'white', 
            fontSize:16, 
            letterSpacing:0.6, 
            textAlign:'center', 
            fontWeight:'bold'}}>Next</Text>
        </TouchableHighlight> 
    );
  }

  buttonDone = () =>
  {
    return(
          <TouchableHighlight
             onPress={()=> this.props.navigation.navigate("Gender")}
           style={{ 
          backgroundColor:'rgba(47, 209, 200, 0.77)', 
           alignItems:'center',   
           padding:15,   
           top:-10,  
           width:320, 
           marginLeft:30,   
           marginRight:30,   
           borderRadius:23,   
           justifyContent:'center' }} >
          <Text style={{
            color:'white',
             fontSize:16,
              letterSpacing:0.6, 
              textAlign:'center', 
              fontWeight:'bold'}}>Get Started</Text>
        </TouchableHighlight>
       
    );
  }
  
  onDone =()=> {
    this.setState({showOnboard:true});
  }
  
  render() {
      if(this.state.showOnboard)
      {
        return <Onboard/>
      }else
      return <AppIntroSlider 
      renderItem={this.item_render} 
      slides={slides} 
      done={this.onDone}
      activeDotStyle={styles.activedots}
      dotStyle={styles.inactivedots}
      renderNextButton={this.buttonNext}
      renderDoneButton={this.buttonDone} 
      skipLabel={this.skip}
      // showSkipButton = true
      />
  }
}


  const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
  },
  styleSkip:{
    color:'white',
    left:140,
    top:50,
    fontWeight:'bold',
    fontSize: 16,
    letterSpacing:0.6,
    // borderRadius:23,
    // borderWidth:2,
    paddingTop:5,
    paddingLeft: 20,
    paddingRight: 20,
    paddingBottom:5,
    // borderColor:'rgba(47, 209, 200, 0.77)',
    alignSelf:'center',
    justifyContent: 'center',
    // marginLeft:40,
    // marginRight:40
  },
  titleStyle:{
    alignItems:'center',
    fontSize: 16,
    color:'#625E5E',
    fontWeight:'bold',
    height: '-10%',
    textAlign:'center',
    marginTop: 200,
    letterSpacing:0.2,
    marginLeft:40,
    marginRight:40 
    // fontFamily:'nunito-bold'  
  },
  subtitle:{
    alignItems:'center',
    fontSize:14,
    color:'#888686',
    marginBottom:20,
    height: '-20%',
    textAlign:'center',
    marginTop: 30,
    letterSpacing:0.2,
    marginLeft:60,
    marginRight:60
    
    // fontFamily:'nunito-regular'
  },
  picture:{
    width: 200,
    height: 200,
    alignSelf:'center',
    top: 150,
    
  },
  slide:{
    flex:0.15,
    backgroundColor:'rgba(49, 158, 145, 0.800137)',
    borderBottomLeftRadius:30,
    borderBottomRightRadius:30,
    
  },
  activedots:{
      backgroundColor:"rgba(50, 225, 215, 0.54)",
      marginBottom:150,
      
  },
  inactivedots:{
    backgroundColor:'#2E94CD',
    marginBottom:150,
    // fontSize:10,
  },
  buttondone:{
    // width:235,
    // height:50,
    // left:10,
    // justifyContent:'center',
    // marginRight:70,
  },
  buttonnext:{
    // width:235,
    // height:50,
    // left:10,
    // justifyContent:'center',
    // marginRight:70,
  },
});
