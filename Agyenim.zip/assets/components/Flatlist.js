import React from 'react';
import {View,StyleSheet,ScrollView,ActivityIndicator,Flatlist,Text,TouchableOpacity} from 'react-native';

export default class Showlist extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            loading:true,
            datasource:[]
        };
    }
    
    componentDidMount(){
        fetch("https://jsonplaceholder.typicode.com/users")
        .then(response => response.json() )
        .then((responseJSON) => { //returns a promise
            this.setState({
                loading:false,
                datasource:responseJSON
            })
        })
        .catch(error => alert(error))  //to catch errors if any
    }
    FlatListItemSeparator = () => {
        return(
            <View
                style ={{height:5,width:'100%',backgroundColor:"rgba(0,0,0,0.5"}}
            />
        );
    }
    
    renderItem = (data) => 
    <View style={styles.list}>
        <Text style={{color:'white'}}>{data.item.name}</Text>
        <Text style={{color:'white'}}>{data.item.email}</Text>
        <Text style={{color:'white'}}>{data.item.company.name}</Text>
    </View>
    
    render(){
        if(this.state.loading){
           return(
           <View style={styles.loader}>
        <ActivityIndicator
            size="large" color="rgba(47, 209, 200, 0.77)"/>
       </View>
               
           )
        }   
        return(
           <ScrollView>
            <View style={styles.container}>
            <Flatlist
               data = {this.state.datasource}
               ItemSeparatorComponent = {this.FlatListItemSeparator}
               renderItem = {item => this.renderItem(item)}
               keyExtractor={item => item.id.toString()}
            />
            </View>
           </ScrollView>
        )};
    }


const styles = StyleSheet.create({
    container:{
        alignItems:'center',
        flex:1,
        justifyContent:'center',
        backgroundColor:'white'
},
loader:{
    flex:1,
    alignItems:'center',
    justifyContent:'center',
}
})

app.get('/',function(req,res){
    res.send('hello world')
})
app.post('/',function(req,res){
    res.send('got a post request')
})