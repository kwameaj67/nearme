import React from 'react';
import {Font} from 'expo';
import {View} from 'react-native';

export default class Font extends React.Component{
   constructor(props){
       super(props);
       this.state={
        fontLoaded:false,
    }
   }
   async componentDidMount () {
     await Font.loadAsync({
           'Nunito-Black': require('../fonts/Nunito-Black.ttf'),
           'Nunito-SemiBold':require('../fonts/Nunito-SemiBold.ttf'),
           'Nunito-Bold': require('../fonts/Nunito-Bold.ttf'),
            'Nunito-ExtraBold': require('../fonts/Nunito-ExtraBold.ttf'),
            'Nunito-Regular':require('../fonts/Nunito-Regular.ttf'),
       });
       this.setState({fontLoaded:true});
   }
    render(){
        return(
            <View></View>
            // {this.componentDidMount()}
        );
    }
}