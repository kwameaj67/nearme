import React from 'React';
import {StyleSheet,View} from 'react-native';
import LinearGradient from 'expo';

export default class LinearGradient extends React.Component{

render(){
    return(
            <LinearGradient
                
            />     
    );
}

}
const styles =StyleSheet.create({
    
    
})