import React from 'react';
import {ScrollView} from 'react-native';
import {DrawerItems,SafeAreaView, createDrawerNavigator} from 'react-navigation';
import Home from '../NavigationDrawer/Home';
import Setting from '../NavigationDrawer/Setting';


export default class Drawer extends React.Component{
    render(){
            return(
               <AppDrawerNavigation/>
            );
        }
    }
    
const AppDrawerNavigation = createDrawerNavigator({
    Home:Home,
    Setting:Setting,
},
 {  
    contentComponent:CustomNavigationDrawer
}
)
const CustomNavigationDrawer = (props) => (
    <SafeAreaView style={{flex:1}}>
            <ScrollView>
                     <DrawerItems {...props}/>
            </ScrollView>
    </SafeAreaView>
)


