import React from 'react';
import {View,Text} from 'react-native';
import {Header,Left,Right} from 'native-base';
import {Ionincons} from '@expo/vector-icons';


export default class Home extends React.Component{
render(){
        return(
            <View style={{flex:1,justifyContent:'center',alignContent:'center'}}>
            {/* <Header>
                <Left>
                    <Ionincons name="ios-menu" size={20}/>
                </Left>
            </Header> */}
            <View style={{flex:1,justifyContent:'center',alignContent:'center'}}>
                <Text style={{fontSize:24,alignSelf:'center'}}>HomeScreen</Text>
                </View>
            </View>
        );
    }
}
