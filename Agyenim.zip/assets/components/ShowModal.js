import React from 'react';
import {Modal,Dimensions,Alert} from 'react-native';
// import Modal from 'react-native-modalbox';
// import { platform } from 'os';


var screen = Dimensions.get('window');
export default class ShowModal extends React.Component {
constructor()
{
    super(props);
    this.state = {
        modalVisible:true
    }
}

// showAddModal = () => {
//     this.refs.myModal.open();
// }
    render(){
        return(
                <Modal
                    animationType="slide"
                    presentationStyle="pageSheet"
                    transparent={false}
                    style={{
                        justifyContent:"center",
                        borderRadius:30,
                        shadowRadius:10,
                        width:screen.width -80,
                        height:280
                            }}    
                      position='center'
                      backdrop={true}
                       onDismiss={() => {
                             Alert.alert("Modal closed");
                       }}       
                            >
                </Modal>
        );
    }
}

