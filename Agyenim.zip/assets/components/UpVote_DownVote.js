state = {
    productCount:0,
    karma: 0
  }

  Upvote = ()=>{
    var vote = this.state.productCount +1;
    this.setState(
      {
        'productCount': vote,
        'karma' : this.state.karma + 13
      })
  }

  Downvote = ()=>{
    var vote = this.state.productCount -1;
    if(this.state.karma >0){
      this.setState(
        {
          'productCount': vote,
          'karma' : this.state.karma - 11
        })
    }
  }

  <View style={style.container}>
      <Text style={style.karma}>Karma : {this.state.karma}</Text>
      <Button 
            title="Upvote"
            onPress={this.Upvote}
        />
      <Text style={style.number}>{this.state.productCount}</Text>
      <Button 
          title="DownVote"
          onPress={this.Downvote}/>
      
      </View>
       slogan:{
        fontSize:15,
        color:'white',
      },
      karma:{
        fontSize:50,
        color:'white',
      },
      number:{
        color:'white',
        fontSize:15,
        
    },