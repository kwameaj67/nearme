import React from 'react'
import {StyleSheet,View,Text} from 'react-native'

  class Help extends React.Component{

    render(){
        return(
            <View style={styles.container}>
                <Text style={{color:'black'}}> Here is HelpScreen</Text>
            </View>
        );
    }
}
export default Help;
const styles = StyleSheet.create({
container:{
    flex:1,
    justifyContent:'center',
    alignItems:'center'
            }       
})