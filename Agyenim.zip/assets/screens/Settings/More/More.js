import React from 'react'
import {StyleSheet,View,Text,TouchableNativeFeedback} from 'react-native'
import {
    Ionicons,Feather,AntDesign,MaterialIcons, EvilIcons
} from '@expo/vector-icons';


export default  class More extends React.Component{
    static navigationOptions = ({navigation}) => {
        return{
            title:'More Settings',
            headerLeft:(
                <TouchableNativeFeedback  useForeground={true}
               
                style={{padding: 10,
                        borderColor: "black",
                        borderRadius: 23
                        }}>
                     <Ionicons name = "ios-arrow-round-back" size = {40}
                            color = "rgba(47, 209, 200, 0.77)"
                            useForeground={true}
                             onPress = {() => navigation.navigate("Settings")}
                             style={{marginLeft:15}}></Ionicons>
                </TouchableNativeFeedback>
            )
        }
    };
    renderMore(){
        <View>
            <TouchableNativeFeedback 
                         useForeground={false} background={TouchableNativeFeedback.SelectableBackground()}
                style = {{}} onPress ={()=>this.props.navigation.navigate("About")} >
                    <View style={{flexDirection:"row",flexGrow:12,paddingVertical:18,alignContent:'center'}}>
                    <Ionicons name="ios-information-circle-outline" size={21} color="rgba(47, 209, 200, 0.77)" style={{marginLeft:30}}/>
                    <Text style={{marginLeft:20, fontSize:15, color:"#625E5E",fontStyle:"normal",fontWeight:"300"}}>About</Text>
                    <Ionicons name="ios-arrow-forward" size={20} color="#BAB3B3"  style={{marginBottom:5,marginLeft:250}} />
                    </View>    
            </TouchableNativeFeedback>  
                <TouchableNativeFeedback 
                         useForeground={false} background={TouchableNativeFeedback.SelectableBackground()}
                style = {{}}  onPress ={()=>this.props.navigation.navigate("Help")}>
                    <View style={{flexDirection:"row",flexGrow:12,paddingVertical:18,alignContent:'center'}}>
                    <Ionicons name="ios-help-circle-outline" size={21} color="rgba(47, 209, 200, 0.77)" style={{marginLeft:30}}/>
                    <Text style={{marginLeft:20, fontSize:15, color:"#625E5E",fontStyle:"normal",fontWeight:"300"}}>Help</Text>
                    <Ionicons name="ios-arrow-forward" size={20} color="#BAB3B3"  style={{marginBottom:5,marginLeft:240}} />
                    </View>    
            </TouchableNativeFeedback>  
        </View>
    }
    render(){
        return(
            <View style={styles.container}>
                {this.renderMore()}
            </View>
        );
    }
}

const styles = StyleSheet.create({
container:{
    flex:1,
    justifyContent:'center',
    backgroundColor:'white'
}
})