import React from 'react'
import {StyleSheet,View,Text,TouchableNativeFeedback,ActivityIndicator} from 'react-native'
import {
    Ionicons,Feather,AntDesign,MaterialIcons, EvilIcons
} from '@expo/vector-icons';

export default  class Notifications extends React.Component{

    static navigationOptions = ({navigation}) => {
        return{
            title:'Notifications',
            headerLeft:(
                <TouchableNativeFeedback  useForeground={true}
               
                style={{padding: 10,
                        borderColor: "black",
                        borderRadius: 23
                        }}>
                     <Ionicons name = "ios-arrow-round-back" size = {40}
                            color = "rgba(47, 209, 200, 0.77)"
                            useForeground={true}
                             onPress = {() => navigation.pop()}
                             style={{marginLeft:15}}></Ionicons>
                </TouchableNativeFeedback>
            )
        }
    };
    render(){
        return(
            <View style={styles.container}>
                <ActivityIndicator size="large" color="rgba(47, 209, 200, 0.77)" animating={true}>

                </ActivityIndicator>
                {/* <Text style={{color:'black'}}> Here is NotificationsScreen</Text> */}
            </View>
        );
    }
}

const styles = StyleSheet.create({
container:{
    flex:1,
    justifyContent:'center',
    alignItems:'center'
}
})