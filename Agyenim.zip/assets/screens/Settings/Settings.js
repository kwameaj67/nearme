import React from 'react'
import { StyleSheet,View,Text,TouchableNativeFeedback,TouchableHighlight} from 'react-native'
import {
    Ionicons,Feather,AntDesign,MaterialIcons, EvilIcons
} from '@expo/vector-icons';
import { BorderlessButton } from 'react-native-gesture-handler';

export default class Settings extends React.Component {  
    static navigationOptions = ({navigation}) => {
        return{
            // title:
            headerLeft:(
                 <TouchableNativeFeedback  useForeground={true}
               
               style={{padding: 10,
                       borderColor: "black",
                       borderRadius: 23
                       }}>
                    <Ionicons name = "ios-arrow-round-back" size = {40}
                           color = "rgba(47, 209, 200, 0.77)"
                           useForeground={true}
                            onPress = {() => navigation.pop()}
                            style={{marginLeft:15}}></Ionicons>
               </TouchableNativeFeedback>
               
            )
           
        }
    };
    renderSettings(){
        return(
            <View style={styles.container}>
            <View style={{}}>
                <Text style={{
                        fontSize: 35,
                        fontWeight: "900",
                        // color: "#625E5E",
                        color:'black',
                         marginTop:-120, 
                         marginBottom:150,  
                        marginLeft:30,
                        marginRight:30,
                        letterSpacing:0.6, 
                        alignItems:'center'}}>Settings
                </Text>
                      {/* <View style={{borderColor:"#D9D6D6",borderBottomWidth:0.8, marginTop:-140,marginBottom:100}}></View> */}
            </View>               
             <View style={{marginTop:-140}}>
             <TouchableNativeFeedback 
                         useForeground={false} background={TouchableNativeFeedback.SelectableBackground()}
                style = {{}} onPress ={()=>this.props.navigation.navigate("Info")} >
                    <View style={{flexDirection:"row",flexGrow:12,paddingVertical:18,alignContent:'center'}}>
                    <Ionicons name="ios-person" size={21} color="rgba(47, 209, 200, 0.77)" style={{marginLeft:30}}/>
                    <Text style={{marginLeft:20, fontSize:15, color:"#625E5E",fontStyle:"normal",fontWeight:"300",letterSpacing:0.4}}>My Info</Text>
                    <Ionicons name="ios-arrow-forward" size={18} color="#BAB3B3"  style={{marginBottom:5,marginLeft:260}} />
                    </View>    
            </TouchableNativeFeedback>  
                <TouchableNativeFeedback 
                         useForeground={true} background={TouchableNativeFeedback.SelectableBackground()}
                style = {{}}  onPress ={()=>this.props.navigation.navigate("Posts")}>
                    <View style={{flexDirection:"row",flexGrow:12,paddingVertical:18,alignContent:'center'}}>
                    <Feather name="send" size={21} color="rgba(47, 209, 200, 0.77)" style={{marginLeft:30}}/>
                    <Text style={{marginLeft:20, fontSize:15, color:"#625E5E",fontStyle:"normal",fontWeight:"300",letterSpacing:0.4}}>My Post</Text>
                    <Ionicons name="ios-arrow-forward" size={18} color="#BAB3B3"  style={{marginBottom:5,marginLeft:250}} />
                    </View>    
            </TouchableNativeFeedback>  
            <TouchableNativeFeedback 
                         useForeground={true} background={TouchableNativeFeedback.SelectableBackground()}
                style = {{}}  onPress ={()=>this.props.navigation.navigate("Replies")}>
                    <View style={{flexDirection:"row",flexGrow:12,paddingVertical:18,alignContent:'center'}}>
                    <Feather name="message-square" size={21} color="rgba(47, 209, 200, 0.77)" style={{marginLeft:30}}/>
                    <Text style={{marginLeft:20, fontSize:15, color:"#625E5E",fontStyle:"normal",fontWeight:"300",letterSpacing:0.4}}>My Replies</Text>
                    <Ionicons name="ios-arrow-forward" size={18} color="#BAB3B3"  style={{marginBottom:5,marginLeft:230}} />
                    </View>    
            </TouchableNativeFeedback>    
            <TouchableNativeFeedback 
                         useForeground={true} background={TouchableNativeFeedback.SelectableBackground()}
                style = {{}}  onPress ={()=>this.props.navigation.navigate("Votes")}>
                    <View style={{flexDirection:"row",flexGrow:12,paddingVertical:18,alignContent:'center'}}>
                    <AntDesign name="like2" size={20} color="rgba(47, 209, 200, 0.77)" style={{marginLeft:30}}/>
                    <Text style={{marginLeft:20, fontSize:15, color:"#625E5E",fontStyle:"normal",fontWeight:"300",letterSpacing:0.4}}>My Votes</Text>
                    <Ionicons name="ios-arrow-forward" size={18} color="#BAB3B3"  style={{marginBottom:5,marginLeft:240}} />
                    </View>    
            </TouchableNativeFeedback> 
            <TouchableNativeFeedback 
                         useForeground={true} background={TouchableNativeFeedback.SelectableBackground()}
                style = {{}}  onPress ={()=>this.props.navigation.navigate("Notifications")}>
                    <View style={{flexDirection:"row",flexGrow:12,paddingVertical:18,alignContent:'center'}}>
                    <MaterialIcons name="notifications-none" size={21} color="rgba(47, 209, 200, 0.77)" style={{marginLeft:30}}/>
                    <Text style={{marginLeft:20, fontSize:15, color:"#625E5E",fontStyle:"normal",fontWeight:"300",letterSpacing:0.4}}>My Notifications</Text>
                    <Ionicons name="ios-arrow-forward" size={18} color="#BAB3B3"  style={{marginBottom:5,marginLeft:190}} />
                    </View>    
            </TouchableNativeFeedback> 
            <TouchableNativeFeedback 
                         useForeground={true} background={TouchableNativeFeedback.SelectableBackground()}
                style = {{}}  onPress ={()=>this.props.navigation.navigate("More")}>
                    <View style={{flexDirection:"row",flexGrow:12,paddingVertical:18,alignContent:'center'}}>
                    <MaterialIcons name="more" size={21} color="rgba(47, 209, 200, 0.77)" style={{marginLeft:30}}/>
                    <Text style={{marginLeft:20, fontSize:15, color:"#625E5E",fontStyle:"normal",fontWeight:"300",letterSpacing:0.4}}>More</Text>
                    <Ionicons name="ios-arrow-forward" size={18} color="#BAB3B3"  style={{marginBottom:5,marginLeft:270}} />
                    </View>    
            </TouchableNativeFeedback> 
                </View>
            <View>
                <Text></Text>
            </View>
            <View style={{}}>
            <TouchableHighlight underlayColor="transparent" style={styles.button} onPress={()=>this.props.navigation.navigate("Invite")} >
                <View style={{flexDirection:'row'}}>
                <Text style={styles.text}>INVITE FRIENDS</Text>
                <EvilIcons name="arrow-right" size={30} color="white" style={{marginLeft:15}}/>
                </View>
                
            </TouchableHighlight>
            </View>
            

         </View>
        )
    }
    render() {
        return (
            <View style={styles.container}>
                 {this.renderSettings()}
               
            </View>
          
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor:'white'
    },
    button:{
        backgroundColor:'rgba(47, 209, 200, 0.77)',
        alignItems:'center',
        padding:15,
        marginLeft:30,
        marginRight:30,
        top:20,
        borderRadius:23,          
        justifyContent:'center',
        top:60,
    },
    text:{
        color:'white',
        fontWeight:'bold',
        fontSize:15,
        alignItems:'center',
        letterSpacing:0.6
    }
    
})